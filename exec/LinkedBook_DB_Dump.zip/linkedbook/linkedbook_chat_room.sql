-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: linkedbook.co8twancy1pk.ap-northeast-2.rds.amazonaws.com    Database: linkedbook
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `chat_room`
--

DROP TABLE IF EXISTS `chat_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '채팅방 번호',
  `deal_id` int NOT NULL COMMENT '거래 번호',
  `room_id` varchar(100) NOT NULL COMMENT '채팅방 아이디',
  `name` varchar(45) NOT NULL COMMENT '채팅방 이름',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='유저 채팅방 관리';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room`
--

LOCK TABLES `chat_room` WRITE;
/*!40000 ALTER TABLE `chat_room` DISABLE KEYS */;
INSERT INTO `chat_room` VALUES (167,174,'c10ee397-44aa-41b8-b418-99aff8d3a426','deal174 user 84 and 83'),(168,177,'d7c5d150-3b29-4d2c-92d2-73c4439df2e5','deal177 user 85 and 82'),(169,190,'6d77fc4a-fdc0-4339-bdfd-4f50126ffd20','deal190 user 84 and 83'),(170,192,'91a41bcc-0c7f-47d2-a4a0-f55ee7979ed2','deal192 user 83 and 86'),(171,177,'0efb2f31-65c6-45b0-8fdd-5687da59c658','deal177 user 83 and 82'),(172,197,'dc6c6245-0336-4333-a0ce-29771f894a78','deal197 user 83 and 84'),(173,200,'e5780bcc-5ff5-4e76-aabb-edf648bd3e9a','deal200 user 82 and 85'),(174,186,'602f52cd-ac8f-48d1-a767-409f874332a7','deal186 user 86 and 84'),(175,201,'d21d7370-7e1c-493e-bb51-8acbd4ef4206','deal201 user 86 and 82'),(176,190,'c2ffd159-2bba-4b9e-92ef-30ae0fc1b7e9','deal190 user 86 and 83'),(177,204,'8cec29d5-e6a5-47e0-8f15-8bcf71c45abc','deal204 user 84 and 81'),(178,199,'074dc30b-81f0-49d5-b9e8-5cec972a5a6b','deal199 user 88 and 82'),(179,227,'9a7c7aa3-36c2-4cc6-bc2f-264874b26d52','deal227 user 88 and 82'),(180,228,'ca66533c-1bb4-4ecb-a476-ebb4b0a79972','deal228 user 83 and 82'),(181,192,'ab089272-f80c-42a2-9edf-aa4d76ba088e','deal192 user 91 and 86'),(182,229,'53137398-bc80-4e69-87a2-c4fc8ee51c79','deal229 user 83 and 93'),(183,175,'88bba60f-05e6-4215-8720-e0b4c990374e','deal175 user 95 and 86');
/*!40000 ALTER TABLE `chat_room` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  0:47:14
