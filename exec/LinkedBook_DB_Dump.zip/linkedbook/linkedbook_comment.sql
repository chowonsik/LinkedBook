-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: linkedbook.co8twancy1pk.ap-northeast-2.rds.amazonaws.com    Database: linkedbook
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '댓글 번호',
  `book_id` char(13) NOT NULL COMMENT '책 번호',
  `user_id` int NOT NULL COMMENT '유저 번호',
  `score` double NOT NULL COMMENT '댓글 점수',
  `content` text NOT NULL COMMENT '댓글 내용',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '댓글 생성일',
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '댓글 수정일',
  PRIMARY KEY (`id`),
  KEY `FK_comment_book_id_book_id` (`book_id`),
  KEY `FK_comment_user_id_user_id` (`user_id`),
  CONSTRAINT `FK_comment_book_id_book_id` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `FK_comment_user_id_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=273 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='FK_comment_user_id_user_id';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (251,'9788971968413',85,4,'눈물없이 볼 수 없는 응아스토리..⭐️','2021-08-19 06:56:18','2021-08-19 06:56:18'),(252,'9791162540640',86,4,'진짜 작습니다 해보세요 여러분','2021-08-19 07:22:16','2021-08-19 07:22:16'),(253,'9791162540640',82,5,'이책을 읽고 작은 습관이 얼마나 중요한지 깨닫게 되었습니다.','2021-08-19 07:22:26','2021-08-19 07:22:26'),(254,'9791162540640',84,5,'이거 소장하고 종종 읽으면 좋을 것 같아요..!','2021-08-19 07:22:54','2021-08-19 07:22:54'),(255,'9791162540640',83,4,'습관의 힘을 알게 되었습니다.','2021-08-19 07:23:03','2021-08-19 07:23:03'),(256,'9791162540640',81,3,'지금도 종종 다시 꺼내서 읽어보는 책입니다 호랑이','2021-08-19 07:24:54','2021-08-19 07:24:54'),(257,'9791187799030',81,2,'사람마다 효과가 다릅니다','2021-08-19 07:27:10','2021-08-19 07:27:10'),(258,'9791162540640',85,2,'좋은 책이지만,  너무 어려워서 뜻을 이해하기 어려웠어요 ?','2021-08-19 07:29:21','2021-08-19 07:29:21'),(259,'9788971968413',83,5,'이거읽고 펑펑 울었습니다 ㅠㅠ','2021-08-19 07:31:09','2021-08-19 07:31:09'),(260,'9788932903491',81,4,'조금은 어렵지만 흥미진진해요!!','2021-08-19 07:31:54','2021-08-19 07:31:54'),(261,'9788954431347',81,3,'그냥저냥 읽을만해요!! ','2021-08-19 07:32:33','2021-08-19 07:32:33'),(262,'9791160573718',81,4,'돌고래들의 행동을 새롭게 이해할 수 있었어요~','2021-08-19 07:32:57','2021-08-19 07:32:57'),(263,'9788932903491',86,4,'여유로울 때 한 번씩 읽기 좋아요','2021-08-19 07:35:04','2021-08-19 07:35:04'),(264,'9788980104802',83,5,'100번읽었는데 아직도 누가 옮겼는지 모릅니다.','2021-08-19 07:35:10','2021-08-19 07:35:10'),(265,'9788954611800',83,4,'IQ 60이라 잘 이해가 안돼요 ㅠㅠ','2021-08-19 07:37:25','2021-08-19 07:37:25'),(270,'9788926881378',83,5,'이 책을 읽고 사육사가 되었습니다.','2021-08-19 12:16:26','2021-08-19 12:16:26'),(271,'9791160501742',83,4,'이 책을 읽고 농부가 되었습니다.','2021-08-19 12:17:20','2021-08-19 12:17:20'),(272,'9791157952830',83,4,'넘 재밌읍니다^_^','2021-08-19 12:17:55','2021-08-19 12:17:55');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  0:47:13
