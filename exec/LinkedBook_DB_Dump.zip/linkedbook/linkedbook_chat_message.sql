-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: linkedbook.co8twancy1pk.ap-northeast-2.rds.amazonaws.com    Database: linkedbook
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `chat_message`
--

DROP TABLE IF EXISTS `chat_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_message` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '메시지 번호',
  `room_id` int NOT NULL COMMENT '채팅방 번호',
  `to_user_id` int NOT NULL COMMENT '메시지 보낸 유저',
  `from_user_id` int NOT NULL COMMENT '메시지 받은 유저',
  `type` varchar(45) NOT NULL COMMENT '메시지 타입',
  `message` text NOT NULL COMMENT '메시지 내용',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '메시지 생성일',
  PRIMARY KEY (`id`),
  KEY `FK_chat_message_room_id_chat_room_id` (`room_id`),
  KEY `FK_chat_message_to_user_id_user_id` (`to_user_id`),
  KEY `FK_chat_message_from_user_id_user_id` (`from_user_id`),
  CONSTRAINT `FK_chat_message_from_user_id_user_id` FOREIGN KEY (`from_user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `FK_chat_message_room_id_chat_room_id` FOREIGN KEY (`room_id`) REFERENCES `chat_room` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `FK_chat_message_to_user_id_user_id` FOREIGN KEY (`to_user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=902 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='유저 채팅 메시지 관리';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_message`
--

LOCK TABLES `chat_message` WRITE;
/*!40000 ALTER TABLE `chat_message` DISABLE KEYS */;
INSERT INTO `chat_message` VALUES (806,167,83,84,'ENTER','고구마깡님이 입장했습니다.','2021-08-19 06:55:57'),(807,167,83,84,'TALK','해위해위','2021-08-19 06:56:00'),(808,167,83,84,'TALK','이거 제가 사고싶은데','2021-08-19 06:56:18'),(809,167,83,84,'TALK','거래 언제가능하세요','2021-08-19 06:56:23'),(810,167,84,83,'TALK','새벽 4시에 일과가 끝나서 새벽 4시부터 8시 반까지 가능합니다.','2021-08-19 06:59:26'),(811,168,82,85,'ENTER','책귀신님이 입장했습니다.','2021-08-19 07:04:25'),(812,168,82,85,'TALK','아직 특화 안하셨자나요','2021-08-19 07:04:32'),(813,169,83,84,'ENTER','고구마깡님이 입장했습니다.','2021-08-19 07:09:51'),(814,169,83,84,'TALK','그래서 사귀셨나요?','2021-08-19 07:09:55'),(815,169,83,84,'TALK','고백 후 결과에 따라','2021-08-19 07:09:59'),(816,169,83,84,'TALK','구매여부 결정하겠습니다.','2021-08-19 07:10:03'),(817,169,84,83,'TALK','그건 제 프라이머리라 알려드릴수없습니다','2021-08-19 07:11:13'),(818,170,86,83,'ENTER','닉네임님이 입장했습니다.','2021-08-19 07:11:34'),(819,170,86,83,'TALK','용의자 Y는 없나요?','2021-08-19 07:11:43'),(820,171,82,83,'ENTER','닉네임님이 입장했습니다.','2021-08-19 07:12:23'),(821,171,82,83,'TALK','그래서 상 탔나요?','2021-08-19 07:12:29'),(822,172,84,83,'ENTER','닉네임님이 입장했습니다.','2021-08-19 07:13:59'),(823,172,84,83,'TALK','이거읽으면 해커될수있는건가요','2021-08-19 07:14:08'),(824,173,85,82,'ENTER','씨유썬칩도둑님이 입장했습니다.','2021-08-19 07:28:22'),(825,173,85,82,'TALK','책 삽니다','2021-08-19 07:28:28'),(826,173,85,82,'TALK','한밭대학교 앞으로 와주세요','2021-08-19 07:28:33'),(827,173,85,82,'TALK','저녁 6시','2021-08-19 07:28:36'),(828,167,83,84,'TALK','ㅋㅋㅋㅋㅋㅋㅋ','2021-08-19 07:28:36'),(829,167,83,84,'TALK','새벽4시고','2021-08-19 07:28:39'),(830,172,83,84,'TALK','아니요 그냥 크래커요','2021-08-19 07:28:50'),(831,169,83,84,'TALK','프라이다리','2021-08-19 07:29:04'),(832,171,83,82,'TALK','무조건 상탈수 있습니다','2021-08-19 07:29:31'),(833,171,83,82,'TALK','이거 개꿀이에요','2021-08-19 07:29:34'),(834,168,85,82,'TALK','저 3기수료생인데요','2021-08-19 07:29:44'),(835,168,85,82,'TALK','이거 사시면 후회안합니다.','2021-08-19 07:29:58'),(836,168,82,85,'TALK','아 죄송합니다','2021-08-19 07:30:01'),(837,168,82,85,'TALK','다음에 살게요','2021-08-19 07:31:20'),(838,168,85,82,'TALK','아 뭐임.. 진짜','2021-08-19 07:32:55'),(839,172,84,83,'TALK','안사요 수고','2021-08-19 07:33:27'),(840,171,82,83,'TALK','안삼 수고','2021-08-19 07:33:34'),(841,173,85,82,'TALK','대답점','2021-08-19 07:33:39'),(842,170,83,86,'TALK','용!','2021-08-19 07:34:14'),(843,173,82,85,'TALK','한밭대 앞 투썸에서 봐요','2021-08-19 07:34:39'),(844,174,84,86,'ENTER','체체쿨레라님이 입장했습니다.','2021-08-19 07:36:38'),(845,174,84,86,'TALK','이 췍 도움 많이 되나요??','2021-08-19 07:36:45'),(846,175,82,86,'ENTER','체체쿨레라님이 입장했습니다.','2021-08-19 07:36:56'),(847,175,82,86,'TALK','도둑님 10%만 할인해주세요~','2021-08-19 07:37:09'),(848,175,86,82,'TALK','우리집쪽에서 거래하면 해드림요','2021-08-19 07:38:30'),(849,175,86,82,'TALK','한밭대 뚜레쥬르 앞으로 오시면 10%할인해드림','2021-08-19 07:38:45'),(850,174,86,84,'TALK','아뇨','2021-08-19 08:22:30'),(851,174,86,84,'TALK','안봐서 ','2021-08-19 08:22:31'),(852,174,86,84,'TALK','도움안되요','2021-08-19 08:22:35'),(853,175,82,86,'TALK','제가 지금 미국 출장 중이라 다음 달에 거래 가능할까요??','2021-08-19 08:22:55'),(854,174,84,86,'TALK','뭐야!','2021-08-19 08:23:04'),(855,174,84,86,'TALK','안사','2021-08-19 08:23:05'),(856,176,83,86,'ENTER','체첵쿨레라님이 입장했습니다.','2021-08-19 08:23:17'),(857,176,83,86,'TALK','연애 잘하시나요?','2021-08-19 08:23:22'),(858,177,81,84,'ENTER','고구마깡님이 입장했습니다.','2021-08-19 08:43:33'),(859,178,82,88,'ENTER','애기원식님이 입장했습니다.','2021-08-19 09:07:26'),(870,178,82,88,'TALK','안녕하세요 사고싶어서 연락드렸습니다!','2021-08-19 10:44:27'),(871,178,88,82,'TALK','네 안녕하세요','2021-08-19 10:44:30'),(872,178,88,82,'TALK','저녁 6시 한밭대 앞에서 보실래요?','2021-08-19 10:44:37'),(873,178,82,88,'TALK','네 좋습니다!!','2021-08-19 10:44:41'),(874,179,82,88,'ENTER','애기원식님이 입장했습니다.','2021-08-19 10:52:10'),(880,179,82,88,'TALK','안녕하세요','2021-08-19 10:55:20'),(881,179,88,82,'TALK','안녕하세요','2021-08-19 10:55:22'),(882,179,88,82,'TALK','사실건가요?','2021-08-19 10:55:24'),(883,179,82,88,'TALK','네 사고싶어요','2021-08-19 10:55:30'),(884,179,82,88,'TALK','한밭대앞에서 볼 수 있을까요?','2021-08-19 10:55:41'),(885,179,88,82,'TALK','알겠습니다 저녁 9시에 봐요 ㅎㅎ','2021-08-19 10:55:51'),(886,180,82,83,'ENTER','대웅짱1234님이 입장했습니다.','2021-08-19 11:11:18'),(887,180,82,83,'TALK','저한테파셈','2021-08-19 11:11:22'),(888,181,86,91,'ENTER','SsAFY님이 입장했습니다.','2021-08-19 11:18:23'),(889,181,86,91,'TALK','책을 구매할 수 있을까요?','2021-08-19 11:18:53'),(890,181,91,86,'TALK','네 가능합니다!!','2021-08-19 11:19:32'),(891,181,91,86,'TALK','시간 언제가 괜찮으세요?','2021-08-19 11:19:37'),(892,181,86,91,'TALK','내일 저녁쯤에 시간이 될 것 같아요~','2021-08-19 11:20:31'),(893,181,86,91,'TALK','내일 저녁 6시에 거래할까요??','2021-08-19 11:20:52'),(894,182,93,83,'ENTER','대웅짱1234님이 입장했습니다.','2021-08-19 11:27:58'),(895,182,93,83,'TALK','저한테파세요','2021-08-19 11:28:01'),(896,182,83,93,'TALK','네 ㅎㅎㅎ','2021-08-19 11:28:09'),(897,183,86,95,'ENTER','책벌레입니다님이 입장했습니다.','2021-08-19 12:21:02'),(898,183,86,95,'TALK','책 사고싶어요!','2021-08-19 12:21:31'),(899,180,83,82,'TALK','싫음','2021-08-19 15:29:55'),(900,180,83,82,'TALK','혼나고싶음?','2021-08-19 15:29:58'),(901,180,83,82,'TALK','졸림 ㅜ','2021-08-19 15:30:10');
/*!40000 ALTER TABLE `chat_message` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  0:47:11
