-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: linkedbook.co8twancy1pk.ap-northeast-2.rds.amazonaws.com    Database: linkedbook
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '유저 번호',
  `email` varchar(45) NOT NULL COMMENT '유저 이메일',
  `password` varchar(45) NOT NULL COMMENT '유저 비밀번호',
  `nickname` varchar(45) NOT NULL COMMENT '유저 닉네임',
  `info` text NOT NULL COMMENT '유저 소개',
  `image` text NOT NULL COMMENT '유저 이미지',
  `oauth` varchar(45) DEFAULT NULL COMMENT 'Google, Kakao',
  `oauth_id` varchar(255) DEFAULT NULL,
  `status` varchar(45) NOT NULL DEFAULT 'ACTIVATE' COMMENT 'ACTIVATE : 활성화된 유저, DELETED : 삭제된 유저',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '유저 생성일',
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '유저 수정일',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='유저 정보 관리';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (81,'kihafif125@hax55.com','CN9DfEh9wuVzbHJmCimQOQ==','둥물원','저는 호랑이입니다','https://linkedbook.s3-ap-northeast-2.amazonaws.com/images/user-202181916243661프사1.JPG',NULL,NULL,'ACTIVATE','2021-08-19 06:51:14','2021-08-19 07:24:17'),(82,'cwscms@naver.com','EuvZrGJNLg5AJvQQoQ/vsw==','씨유썬칩도둑','','https://k.kakaocdn.net/dn/cDxefA/btqRqScxvUD/glDzwjOMwZkAMmhsJKzurk/img_640x640.jpg','KAKAO','1854787922','ACTIVATE','2021-08-19 06:52:10','2021-08-19 06:52:10'),(83,'dwbyun16@gmail.com','k+uturLvk+n89Xg+tzYa3Q==','대웅짱1234','안녕하세요 반갑습니다~','https://linkedbook.s3-ap-northeast-2.amazonaws.com/images/user-2021819162523931프사.jpg',NULL,NULL,'ACTIVATE','2021-08-19 06:52:23','2021-08-19 09:04:22'),(84,'gokoy23840@alltekia.com','0K98yYxOUxIjUDgm6BPJIQ==','고구마깡','고구마깡 먹고싶다.','https://linkedbook.s3-ap-northeast-2.amazonaws.com/images/user-2021819162453584KakaoTalk_20210819_111257713.jpg',NULL,NULL,'ACTIVATE','2021-08-19 06:52:50','2021-08-19 07:47:04'),(85,'qhdld47@nate.com','ur+4Vwb8YXvQToaK8VUqUQ==','책귀신','','https://linkedbook.s3-ap-northeast-2.amazonaws.com/images/user-202181915542572770173618-C6F6-431A-8E1D-7C5D64AC7219.jpeg','KAKAO','1853562500','ACTIVATE','2021-08-19 06:53:19','2021-08-19 06:55:08'),(86,'alcls950@naver.com','CN9DfEh9wuVzbHJmCimQOQ==','체첵쿨레라','','https://linkedbook.s3-ap-northeast-2.amazonaws.com/images/user-2021819161834847cat.png',NULL,NULL,'ACTIVATE','2021-08-19 06:53:25','2021-08-19 07:51:15'),(87,'wakasa2407@cytsl.com','CN9DfEh9wuVzbHJmCimQOQ==','뭉게뭉게','','https://linkedbook.s3-ap-northeast-2.amazonaws.com/images/user-2021819164113969프사2.JPG',NULL,NULL,'ACTIVATE','2021-08-19 07:40:33','2021-08-19 07:41:16'),(88,'wscho94@gmail.com','wfyNhMkspn3a1C6DJKCmmg==','애기원식','응애 나 애기원식!','https://lh3.googleusercontent.com/a/AATXAJzoJ3sIpSC-_KA5fpzD4wLc2vJJyQK6AG5YSk8p=s96-c','GOOGLE','109440853956862708975','ACTIVATE','2021-08-19 07:44:18','2021-08-19 07:44:43'),(89,'revotox680@error57.com','CN9DfEh9wuVzbHJmCimQOQ==','매운맛을보여주지','','https://linkedbook.s3-ap-northeast-2.amazonaws.com/images/user-2021819171829771프사3.JPG',NULL,NULL,'ACTIVATE','2021-08-19 08:17:54','2021-08-19 08:19:06'),(90,'yitopey968@fada55.com','CN9DfEh9wuVzbHJmCimQOQ==','ssafy5','','',NULL,NULL,'ACTIVATE','2021-08-19 08:46:29','2021-08-19 08:46:29'),(91,'holef76077@fada55.com','CN9DfEh9wuVzbHJmCimQOQ==','SsAFY','','',NULL,NULL,'ACTIVATE','2021-08-19 08:55:52','2021-08-19 08:55:52'),(92,'detifiv531@cfcjy.com','tcLT6dxmEed9prAGdpTTig==','im_coach','','',NULL,NULL,'ACTIVATE','2021-08-19 09:23:57','2021-08-19 09:23:57'),(93,'dwbyun17@gmail.com','k+uturLvk+n89Xg+tzYa3Q==','틈새라면','','https://lh3.googleusercontent.com/a/AATXAJzJwGn5Kt8UtrpL2RXJb0T0WGf0UfY9eJcM35B5=s96-c','GOOGLE','105985996527898674101','ACTIVATE','2021-08-19 11:17:00','2021-08-19 11:17:00'),(94,'berer72473@error57.com','CN9DfEh9wuVzbHJmCimQOQ==','sssafy','','',NULL,NULL,'ACTIVATE','2021-08-19 12:04:54','2021-08-19 12:04:54'),(95,'caroren580@hax55.com','CN9DfEh9wuVzbHJmCimQOQ==','책벌레입니다','','',NULL,NULL,'ACTIVATE','2021-08-19 12:07:43','2021-08-19 12:07:43'),(96,'jongs3030@naver.com','ymhODDSfkf0eyxyAvwFw3w==','정종우','','https://k.kakaocdn.net/dn/0zh2B/btq5h0t4KGX/7ZpejhV9FjwKTuGeg4YD9K/img_640x640.jpg','KAKAO','1855291531','ACTIVATE','2021-08-19 12:29:40','2021-08-19 12:29:40'),(97,'henry9489@gmail.com','FlINF6B9Um6KG+hBL91GTA==','헬로우','','',NULL,NULL,'ACTIVATE','2021-08-19 12:30:10','2021-08-19 12:30:10'),(98,'henry8904@naver.com','u7+ghYoEwIIKmBjfTutoxQ==','안녕하세요','','https://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg','KAKAO','1857243483','ACTIVATE','2021-08-19 12:31:18','2021-08-19 12:31:18'),(99,'ssej09072@naver.com','ymhODDSfkf0eyxyAvwFw3w==','신형식','','https://k.kakaocdn.net/dn/ccL16a/btraibEA2oY/J8F6n1EeSeRIU55KyrwZ4K/img_640x640.jpg','KAKAO','1857243642','DELETED','2021-08-19 12:31:18','2021-08-19 12:33:54'),(100,'jjh1731@naver.com','EmpykA6Xb+66ZtJXXy8KTA==','정지홍','','https://k.kakaocdn.net/dn/bBbkSC/btqR1sydyOC/BVzUlGoUUCKBS2ATRLN5Bk/img_640x640.jpg','KAKAO','1857243249','ACTIVATE','2021-08-19 12:31:18','2021-08-19 12:31:18'),(101,'ssej09072@naver.com','ymhODDSfkf0eyxyAvwFw3w==','신형식','','https://k.kakaocdn.net/dn/ccL16a/btraibEA2oY/J8F6n1EeSeRIU55KyrwZ4K/img_640x640.jpg','KAKAO','1857243642','ACTIVATE','2021-08-19 12:34:24','2021-08-19 12:34:24');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  0:47:15
